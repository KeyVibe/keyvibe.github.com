$(function(){
	$('#slides').slides({
	preload: true,
	preloadImage: 'img/loading.gif',
	play: 2000,
	pause: 2000,
	hoverPause: true
	});
});